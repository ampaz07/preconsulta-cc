import { useState, useEffect } from "react";
import { enviarNotificaciones } from "./notificaciones.js";

// ── Paleta ──
const C = {
  teal: "#1A7A7A", tealDark: "#145F5F", tealLight: "#E8F5F5", tealMid: "#2A9898",
  teal10: "#F0FAF9", sand: "#F7F4EF", ink: "#1C2B2B", muted: "#6B8080",
  border: "#D4E5E5", white: "#FFFFFF", accent: "#E05A2B", accentLight: "#FDF0EB",
  ok: "#2E7D5E", okLight: "#EAF5EE",
};

// ── Storage ──
const STORE_KEY = "cc_preconsultas_v2";
function loadResponses() {
  try { return JSON.parse(localStorage.getItem(STORE_KEY) || "[]"); } catch { return []; }
}
function saveResponse(data) {
  const all = loadResponses();
  all.unshift({ id: Date.now(), fecha: new Date().toLocaleString("es-CO"), ...data });
  localStorage.setItem(STORE_KEY, JSON.stringify(all));
}
function deleteResponse(id) {
  const all = loadResponses().filter(r => r.id !== id);
  localStorage.setItem(STORE_KEY, JSON.stringify(all));
}

// ── Secciones ──
const SECCIONES = [
  {
    id: "identificacion", titulo: "Datos del niño/a", emoji: "👤",
    campos: [
      { id: "nombre_nino", label: "Nombre completo del niño/a", tipo: "text", required: true },
      { id: "fecha_nac", label: "Fecha de nacimiento", tipo: "date", required: true },
      { id: "edad", label: "Edad actual", tipo: "text", required: true, placeholder: "Ej: 8 años" },
      { id: "grado", label: "Grado / Curso escolar", tipo: "text", required: true, placeholder: "Ej: 3° primaria" },
      { id: "nombre_acudiente", label: "Nombre del acudiente", tipo: "text", required: true },
      { id: "parentesco", label: "Parentesco con el niño/a", tipo: "select", required: true,
        opciones: ["Madre", "Padre", "Abuelo/a", "Tío/a", "Otro cuidador"] },
      { id: "telefono", label: "Teléfono de contacto", tipo: "tel", required: true },
      { id: "convive", label: "¿Con quién vive el niño/a?", tipo: "text", required: true,
        placeholder: "Ej: con ambos padres y una hermana" },
    ]
  },
  {
    id: "motivo", titulo: "Motivo de consulta", emoji: "⭐", destacado: true,
    campos: [
      { id: "motivo_principal", label: "¿Cuál es la razón principal por la que busca consulta?", tipo: "textarea", required: true,
        placeholder: "Descríbala con sus propias palabras, sin preocuparse por los términos técnicos.", rows: 4 },
      { id: "desde_cuando", label: "¿Desde cuándo se observa esta situación?", tipo: "text", required: true,
        placeholder: "Ej: hace 3 meses, desde que entró al colegio…" },
      { id: "quien_identifico", label: "¿Quién lo identificó primero?", tipo: "text",
        placeholder: "Ej: los padres, el colegio, el médico…" },
      { id: "evolucion", label: "Desde que se identificó, ¿cómo ha evolucionado?", tipo: "select",
        opciones: ["Ha empeorado", "Se mantiene igual", "Ha mejorado un poco", "Ha mejorado notablemente"] },
      { id: "intentos", label: "¿Qué han intentado hacer para manejarlo?", tipo: "textarea", rows: 3,
        placeholder: "Ej: hablar con él/ella, cambiar rutinas, consultar al médico…" },
    ]
  },
  {
    id: "salud", titulo: "Salud y desarrollo", emoji: "🩺",
    campos: [
      { id: "complicaciones_emb", label: "¿Hubo complicaciones durante el embarazo o el parto?", tipo: "yesno" },
      { id: "complicaciones_desc", label: "Si las hubo, descríbalas brevemente", tipo: "textarea", rows: 2 },
      { id: "enfermedades", label: "Enfermedades, accidentes o diagnósticos médicos importantes", tipo: "textarea", rows: 2,
        placeholder: "Si no hay ninguno relevante, deje en blanco." },
      { id: "medicacion", label: "¿Consume medicación actualmente?", tipo: "yesno" },
      { id: "medicacion_cual", label: "¿Cuál medicación y por qué razón?", tipo: "text" },
      { id: "primeras_palabras", label: "¿A qué edad dijo sus primeras palabras?", tipo: "text", placeholder: "Ej: al año, a los 18 meses" },
      { id: "camino", label: "¿A qué edad caminó solo/a?", tipo: "text" },
      { id: "dif_lenguaje", label: "¿Dificultades de lenguaje, motoras o de comunicación?", tipo: "yesno" },
      { id: "dif_lenguaje_desc", label: "Si las hay, indique cuáles", tipo: "text" },
    ]
  },
  {
    id: "escolar", titulo: "Historia escolar", emoji: "📚",
    campos: [
      { id: "colegio", label: "Institución educativa actual", tipo: "text", required: true },
      { id: "repitio", label: "¿Ha repetido algún grado escolar?", tipo: "yesno" },
      { id: "desempeno", label: "¿Cómo es su desempeño académico en general?", tipo: "textarea", rows: 2 },
      { id: "relaciones_escuela", label: "¿Cómo es su relación con compañeros y docentes?", tipo: "textarea", rows: 2 },
      { id: "reporte_colegio", label: "¿El colegio ha reportado dificultades?", tipo: "yesno" },
      { id: "reporte_colegio_desc", label: "Si las hay, descríbalas", tipo: "textarea", rows: 2 },
    ]
  },
  {
    id: "familiar", titulo: "Contexto familiar", emoji: "🏠",
    campos: [
      { id: "dinamica", label: "¿Cómo describiría la dinámica familiar en casa?", tipo: "textarea",
        placeholder: "Relación entre padres, entre padres e hijos, entre hermanos." },
      { id: "respuesta_padres", label: "¿Cómo responden cuando el niño/a presenta el comportamiento que los trae a consulta?", tipo: "textarea" },
      { id: "eventos_sig", label: "¿Ha habido eventos familiares significativos recientemente?", tipo: "textarea",
        placeholder: "Ej: separación, duelo, cambio de ciudad…" },
      { id: "ant_psicologico", label: "¿Ha tenido alguna evaluación o proceso psicológico anterior?", tipo: "yesno" },
      { id: "ant_psicologico_desc", label: "¿Quién lo realizó, cuándo y cuál fue el resultado?", tipo: "textarea", rows: 2 },
      { id: "ant_familiar", label: "¿Algún familiar cercano con diagnósticos psicológicos o psiquiátricos?", tipo: "yesno" },
      { id: "ant_familiar_desc", label: "Parentesco y condición", tipo: "text" },
    ]
  },
  {
    id: "conducta", titulo: "Conducta y hábitos", emoji: "🔍",
    campos: [
      { id: "frustracion", label: "¿Cómo reacciona ante la frustración?", tipo: "textarea",
        placeholder: "Cuando se le niega algo, pierde un juego, enfrenta una dificultad…" },
      { id: "miedos", label: "¿Presenta miedos, preocupaciones o síntomas físicos de nerviosismo?", tipo: "textarea",
        placeholder: "Ej: dolor de estómago, insomnio, llanto frecuente…" },
      { id: "sueno", label: "¿El niño/a duerme solo/a?", tipo: "select",
        opciones: ["Sí, solo/a en su cuarto", "A veces pasa a la cama de los padres", "Duerme siempre con los padres u otros"] },
      { id: "alimentacion", label: "¿Cómo es su alimentación?", tipo: "select",
        opciones: ["Sin dificultades", "Come poco o es muy selectivo/a", "Come en exceso", "Hay dificultades específicas"] },
      { id: "intereses", label: "Intereses, hobbies o actividades favoritas", tipo: "text" },
    ]
  },
  {
    id: "expectativas", titulo: "Expectativas", emoji: "🎯",
    campos: [
      { id: "expectativas", label: "¿Qué espera lograr con este proceso?", tipo: "textarea", required: true,
        placeholder: "¿Qué cambio o resultado le indicaría que el proceso fue útil?", rows: 3 },
      { id: "info_adicional", label: "¿Algo más que el psicólogo deba saber antes de la primera sesión?", tipo: "textarea" },
    ]
  }
];

// ── Campo component ──
function Campo({ campo, value, onChange, hasError }) {
  const base = {
    width: "100%", padding: "13px 14px", borderRadius: 12,
    border: `1.5px solid ${hasError ? C.accent : C.border}`,
    fontSize: 16, fontFamily: "inherit", color: C.ink, background: C.white,
    outline: "none", boxSizing: "border-box", WebkitAppearance: "none",
    transition: "border-color 0.15s",
  };

  if (campo.tipo === "yesno") {
    return (
      <div style={{ display: "flex", gap: 10 }}>
        {["Sí", "No"].map(op => (
          <button key={op} onClick={() => onChange(op)} style={{
            flex: 1, padding: "13px 0", borderRadius: 12,
            border: `1.5px solid ${value === op ? C.teal : C.border}`,
            background: value === op ? C.tealLight : C.white,
            color: value === op ? C.teal : C.muted,
            fontWeight: value === op ? 700 : 400,
            fontSize: 16, cursor: "pointer", transition: "all 0.15s",
            fontFamily: "inherit",
          }}>{op}</button>
        ))}
      </div>
    );
  }

  if (campo.tipo === "select") {
    return (
      <div style={{ position: "relative" }}>
        <select value={value || ""} onChange={e => onChange(e.target.value)} style={{
          ...base, paddingRight: 40, cursor: "pointer",
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%236B8080' fill='none' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E")`,
          backgroundRepeat: "no-repeat", backgroundPosition: "right 14px center",
        }}>
          <option value="">Seleccionar…</option>
          {campo.opciones.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      </div>
    );
  }

  if (campo.tipo === "textarea") {
    return (
      <textarea value={value || ""} onChange={e => onChange(e.target.value)}
        placeholder={campo.placeholder || ""} rows={campo.rows || 3}
        style={{ ...base, resize: "vertical", lineHeight: 1.6 }} />
    );
  }

  return (
    <input type={campo.tipo || "text"} value={value || ""}
      onChange={e => onChange(e.target.value)}
      placeholder={campo.placeholder || ""}
      style={base} />
  );
}

// ── Formulario padre ──
function FormularioPadre() {
  const [paso, setPaso] = useState(0);
  const [datos, setDatos] = useState({});
  const [errores, setErrores] = useState([]);
  const [estado, setEstado] = useState("idle"); // idle | enviando | ok | error

  const seccion = SECCIONES[paso];
  const total = SECCIONES.length;
  const progreso = Math.round(((paso) / total) * 100);

  function setVal(id, val) {
    setDatos(d => ({ ...d, [id]: val }));
    setErrores(e => e.filter(x => x !== id));
  }

  function validar() {
    const faltantes = seccion.campos.filter(c => c.required && (!datos[c.id] || !datos[c.id].trim())).map(c => c.id);
    setErrores(faltantes);
    return faltantes.length === 0;
  }

  async function siguiente() {
    if (!validar()) {
      document.getElementById("form-top")?.scrollIntoView({ behavior: "smooth" });
      return;
    }
    if (paso < total - 1) {
      setPaso(p => p + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      await enviar();
    }
  }

  function anterior() {
    setPaso(p => p - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function enviar() {
    setEstado("enviando");
    try {
      saveResponse(datos);
      await enviarNotificaciones(datos);
      setEstado("ok");
    } catch (e) {
      // Guardamos igual aunque falle la notificación
      setEstado("ok");
    }
  }

  if (estado === "ok") {
    return (
      <div style={{ minHeight: "100vh", background: C.teal, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 32, textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>✅</div>
        <h2 style={{ color: C.white, fontSize: 26, fontWeight: 800, margin: "0 0 12px" }}>¡Gracias!</h2>
        <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 16, lineHeight: 1.7, maxWidth: 300, margin: "0 0 32px" }}>
          Su información fue recibida. El psicólogo la revisará antes de su primera sesión y se comunicará con usted para confirmar la cita.
        </p>
        <div style={{ padding: "14px 24px", background: "rgba(255,255,255,0.15)", borderRadius: 14, color: C.white, fontSize: 14 }}>
          <strong>Centro Cognitivo</strong><br />
          Psic. Alfonso Miranda · T.P. 162714
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: seccion.destacado ? "#FFF8F5" : C.sand }}>
      <div id="form-top" />

      {/* Header fijo */}
      <div style={{ background: seccion.destacado ? C.accent : C.teal, padding: "16px 20px 20px", position: "sticky", top: 0, zIndex: 10, boxShadow: "0 2px 12px rgba(0,0,0,0.12)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <span style={{ color: "rgba(255,255,255,0.75)", fontSize: 13, fontWeight: 500 }}>Pre-consulta</span>
          <span style={{ color: "rgba(255,255,255,0.75)", fontSize: 13 }}>{paso + 1} de {total}</span>
        </div>
        <div style={{ background: "rgba(255,255,255,0.25)", borderRadius: 6, height: 5, overflow: "hidden" }}>
          <div style={{ background: C.white, height: 5, width: `${((paso + 1) / total) * 100}%`, borderRadius: 6, transition: "width 0.35s ease" }} />
        </div>
      </div>

      {/* Título sección */}
      <div style={{ padding: "22px 20px 6px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 30 }}>{seccion.emoji}</span>
          <div>
            <h2 style={{ margin: 0, fontSize: 21, fontWeight: 800, color: seccion.destacado ? C.accent : C.ink }}>
              {seccion.titulo}
            </h2>
            {seccion.destacado && (
              <p style={{ margin: "3px 0 0", fontSize: 13, color: C.accent, fontWeight: 500 }}>
                La parte más importante — tómese el tiempo que necesite.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Campos */}
      <div style={{ padding: "12px 20px 120px", display: "flex", flexDirection: "column", gap: 20 }}>
        {seccion.campos.map(campo => (
          <div key={campo.id}>
            <label style={{ display: "block", fontSize: 14, fontWeight: 600, color: C.ink, marginBottom: 7, lineHeight: 1.45 }}>
              {campo.label}
              {campo.required && <span style={{ color: C.accent, marginLeft: 3 }}>*</span>}
            </label>
            <Campo campo={campo} value={datos[campo.id]} onChange={val => setVal(campo.id, val)} hasError={errores.includes(campo.id)} />
            {errores.includes(campo.id) && (
              <p style={{ margin: "5px 0 0", fontSize: 12, color: C.accent, fontWeight: 500 }}>Este campo es obligatorio</p>
            )}
          </div>
        ))}
      </div>

      {/* Nav fija */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: C.white, borderTop: `1px solid ${C.border}`, padding: "12px 20px", display: "flex", gap: 10, boxShadow: "0 -4px 20px rgba(0,0,0,0.08)" }}>
        {paso > 0 && (
          <button onClick={anterior} style={{ flex: 1, padding: "15px", borderRadius: 14, border: `1.5px solid ${C.border}`, background: C.white, color: C.muted, fontSize: 16, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
            ← Atrás
          </button>
        )}
        <button onClick={siguiente} disabled={estado === "enviando"} style={{ flex: 2, padding: "15px", borderRadius: 14, border: "none", background: seccion.destacado ? C.accent : C.teal, color: C.white, fontSize: 16, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", opacity: estado === "enviando" ? 0.7 : 1 }}>
          {estado === "enviando" ? "Enviando…" : paso === total - 1 ? "Enviar formulario ✓" : "Continuar →"}
        </button>
      </div>
    </div>
  );
}

// ── Panel psicólogo ──
function PanelPsicologo({ onSalir }) {
  const [respuestas, setRespuestas] = useState([]);
  const [detalle, setDetalle] = useState(null);

  useEffect(() => { setRespuestas(loadResponses()); }, []);

  function borrar(id, e) {
    e.stopPropagation();
    if (!confirm("¿Eliminar este formulario?")) return;
    deleteResponse(id);
    setRespuestas(loadResponses());
    if (detalle?.id === id) setDetalle(null);
  }

  // Vista detalle
  if (detalle) {
    return (
      <div style={{ minHeight: "100vh", background: C.sand }}>
        <div style={{ background: C.ink, padding: "16px 20px", position: "sticky", top: 0, zIndex: 10, display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => setDetalle(null)} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: C.white, borderRadius: 10, padding: "9px 14px", fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>
            ←
          </button>
          <div style={{ flex: 1 }}>
            <div style={{ color: C.white, fontWeight: 700, fontSize: 16 }}>{detalle.nombre_nino || "—"}</div>
            <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12 }}>{detalle.fecha}</div>
          </div>
        </div>

        <div style={{ padding: "16px 20px 48px", display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Motivo destacado */}
          <div style={{ background: C.accentLight, border: `2px solid ${C.accent}`, borderRadius: 16, padding: "16px" }}>
            <div style={{ color: C.accent, fontWeight: 800, fontSize: 13, letterSpacing: 0.5, marginBottom: 8 }}>⭐ MOTIVO DE CONSULTA</div>
            <p style={{ margin: 0, color: C.ink, fontSize: 15, lineHeight: 1.65 }}>{detalle.motivo_principal || "—"}</p>
            <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 8 }}>
              {detalle.desde_cuando && <Chip label="Desde" value={detalle.desde_cuando} />}
              {detalle.evolucion && <Chip label="Evolución" value={detalle.evolucion} />}
              {detalle.quien_identifico && <Chip label="Identificó" value={detalle.quien_identifico} />}
            </div>
            {detalle.intentos && (
              <p style={{ margin: "10px 0 0", fontSize: 13, color: C.ink }}><strong>Han intentado:</strong> {detalle.intentos}</p>
            )}
          </div>

          {/* Info clave rápida */}
          <div style={{ background: C.white, borderRadius: 16, border: `1px solid ${C.border}`, padding: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: C.teal, marginBottom: 10 }}>📋 DATOS DE CONTACTO</div>
            <InfoRow label="Paciente" value={`${detalle.nombre_nino || "—"}, ${detalle.edad || "—"}, ${detalle.grado || "—"}`} />
            <InfoRow label="Acudiente" value={`${detalle.nombre_acudiente || "—"} (${detalle.parentesco || "—"})`} />
            <InfoRow label="Teléfono" value={detalle.telefono || "—"} />
            <InfoRow label="Vive con" value={detalle.convive || "—"} />
          </div>

          {/* Resto de secciones */}
          {SECCIONES.filter(s => !["identificacion", "motivo"].includes(s.id)).map(sec => {
            const camposConDatos = sec.campos.filter(c => detalle[c.id] && detalle[c.id] !== "");
            if (!camposConDatos.length) return null;
            return (
              <div key={sec.id} style={{ background: C.white, borderRadius: 16, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                <div style={{ padding: "10px 16px", background: C.teal10, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 16 }}>{sec.emoji}</span>
                  <span style={{ fontWeight: 700, fontSize: 13, color: C.teal }}>{sec.titulo}</span>
                </div>
                <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 12 }}>
                  {camposConDatos.map(c => (
                    <div key={c.id}>
                      <div style={{ fontSize: 12, color: C.muted, marginBottom: 3, fontWeight: 500 }}>{c.label}</div>
                      <div style={{ fontSize: 14, color: C.ink, lineHeight: 1.55 }}>{detalle[c.id]}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Expectativas */}
          {detalle.expectativas && (
            <div style={{ background: C.okLight, border: `1.5px solid ${C.ok}`, borderRadius: 16, padding: 16 }}>
              <div style={{ color: C.ok, fontWeight: 700, fontSize: 13, marginBottom: 6 }}>🎯 EXPECTATIVAS</div>
              <p style={{ margin: 0, color: C.ink, fontSize: 14, lineHeight: 1.6 }}>{detalle.expectativas}</p>
              {detalle.info_adicional && (
                <p style={{ margin: "8px 0 0", fontSize: 13, color: C.muted }}><em>{detalle.info_adicional}</em></p>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Lista
  return (
    <div style={{ minHeight: "100vh", background: C.sand }}>
      <div style={{ background: C.ink, padding: "20px 20px 18px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 12, marginBottom: 2 }}>Centro Cognitivo</div>
            <h1 style={{ color: C.white, margin: 0, fontSize: 20, fontWeight: 800 }}>Panel de Pre-consultas</h1>
          </div>
          <button onClick={onSalir} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: "rgba(255,255,255,0.7)", borderRadius: 10, padding: "9px 14px", fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>
            Salir
          </button>
        </div>
        <div style={{ marginTop: 12, display: "inline-block", padding: "5px 12px", background: "rgba(255,255,255,0.1)", borderRadius: 8 }}>
          <span style={{ color: "rgba(255,255,255,0.75)", fontSize: 13 }}>
            {respuestas.length} {respuestas.length === 1 ? "formulario recibido" : "formularios recibidos"}
          </span>
        </div>
      </div>

      <div style={{ padding: "16px 20px 40px", display: "flex", flexDirection: "column", gap: 12 }}>
        {respuestas.length === 0 ? (
          <div style={{ textAlign: "center", padding: "64px 20px" }}>
            <div style={{ fontSize: 44, marginBottom: 14 }}>📋</div>
            <p style={{ color: C.muted, fontSize: 15, margin: 0 }}>Aún no hay formularios.</p>
            <p style={{ color: C.muted, fontSize: 13, margin: "6px 0 0" }}>Comparte el link con los padres para recibir pre-consultas aquí.</p>
          </div>
        ) : (
          respuestas.map(r => (
            <div key={r.id} onClick={() => setDetalle(r)} style={{ background: C.white, borderRadius: 16, border: `1px solid ${C.border}`, padding: 16, cursor: "pointer", transition: "box-shadow 0.15s, transform 0.1s" }}
              onMouseDown={e => e.currentTarget.style.transform = "scale(0.99)"}
              onMouseUp={e => e.currentTarget.style.transform = "scale(1)"}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 16, color: C.ink }}>{r.nombre_nino || "Sin nombre"}</div>
                  <div style={{ fontSize: 13, color: C.muted, marginTop: 2 }}>
                    {[r.edad, r.grado, r.colegio].filter(Boolean).join(" · ")}
                  </div>
                  <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>{r.fecha}</div>
                </div>
                <span style={{ color: C.teal, fontSize: 22, lineHeight: 1 }}>›</span>
              </div>
              {r.motivo_principal && (
                <div style={{ marginTop: 10, padding: "9px 12px", background: C.accentLight, borderRadius: 10, borderLeft: `3px solid ${C.accent}` }}>
                  <p style={{ margin: 0, fontSize: 13, color: C.ink, lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                    {r.motivo_principal}
                  </p>
                </div>
              )}
              <div style={{ display: "flex", gap: 8, marginTop: 11 }}>
                <span style={{ fontSize: 12, color: C.teal, fontWeight: 600 }}>
                  {r.telefono && `📞 ${r.telefono}`}
                </span>
                <span style={{ flex: 1 }} />
                <button onClick={e => borrar(r.id, e)} style={{ fontSize: 12, color: "#C04040", background: "none", border: `1px solid #F0CCCC`, borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}>
                  Eliminar
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function Chip({ label, value }) {
  return (
    <div style={{ background: "rgba(224,90,43,0.1)", borderRadius: 8, padding: "4px 10px" }}>
      <span style={{ fontSize: 11, color: C.accent, fontWeight: 600 }}>{label}: </span>
      <span style={{ fontSize: 12, color: C.ink }}>{value}</span>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
      <span style={{ fontSize: 13, color: C.muted, minWidth: 80, fontWeight: 500 }}>{label}</span>
      <span style={{ fontSize: 13, color: C.ink, flex: 1 }}>{value}</span>
    </div>
  );
}

// ── Pantalla de inicio ──
function Inicio({ onFormulario, onPanel }) {
  return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(160deg, ${C.tealDark} 0%, ${C.teal} 50%, ${C.tealMid} 100%)`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "32px 24px" }}>
      <div style={{ marginBottom: 4, color: "rgba(255,255,255,0.55)", fontSize: 12, letterSpacing: 2, fontWeight: 600 }}>CENTRO COGNITIVO</div>
      <div style={{ fontSize: 48, margin: "12px 0 4px" }}>🧠</div>
      <h1 style={{ color: C.white, fontSize: 30, fontWeight: 900, textAlign: "center", margin: "0 0 8px", lineHeight: 1.15 }}>Pre-consulta</h1>
      <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 15, textAlign: "center", margin: "0 0 48px", lineHeight: 1.65, maxWidth: 280 }}>
        Información inicial para la primera sesión psicológica
      </p>

      <div style={{ width: "100%", maxWidth: 360, display: "flex", flexDirection: "column", gap: 14 }}>
        <button onClick={onFormulario} style={{ padding: "20px 20px", borderRadius: 18, border: "none", background: C.white, color: C.teal, fontSize: 16, fontWeight: 700, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 4px 20px rgba(0,0,0,0.15)", fontFamily: "inherit" }}>
          <span>
            <span style={{ display: "block", fontSize: 12, fontWeight: 500, color: C.muted, marginBottom: 3 }}>Para padres / acudientes</span>
            Llenar formulario
          </span>
          <span style={{ fontSize: 26 }}>📝</span>
        </button>

        <button onClick={onPanel} style={{ padding: "20px 20px", borderRadius: 18, border: "2px solid rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.12)", color: C.white, fontSize: 16, fontWeight: 700, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", justifyContent: "space-between", fontFamily: "inherit" }}>
          <span>
            <span style={{ display: "block", fontSize: 12, fontWeight: 500, color: "rgba(255,255,255,0.6)", marginBottom: 3 }}>Para el psicólogo</span>
            Ver respuestas
          </span>
          <span style={{ fontSize: 26 }}>📊</span>
        </button>
      </div>

      <p style={{ marginTop: 44, color: "rgba(255,255,255,0.4)", fontSize: 12, textAlign: "center" }}>
        Psic. Alfonso Miranda · T.P. 162714
      </p>
    </div>
  );
}

// ── App root ──
export default function App() {
  const [vista, setVista] = useState("inicio");

  if (vista === "formulario") return <FormularioPadre />;
  if (vista === "panel") return <PanelPsicologo onSalir={() => setVista("inicio")} />;
  return <Inicio onFormulario={() => setVista("formulario")} onPanel={() => setVista("panel")} />;
}
