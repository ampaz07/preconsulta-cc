// ── CONFIGURACIÓN DE NOTIFICACIONES ──
// EmailJS: https://www.emailjs.com (gratis hasta 200 emails/mes)
// CallMeBot: WhatsApp gratis sin API de pago

// IMPORTANTE: Estos valores los configuras UNA VEZ en emailjs.com
// Ver README.md para instrucciones paso a paso
const EMAILJS_SERVICE_ID  = import.meta.env.VITE_EMAILJS_SERVICE_ID  || 'TU_SERVICE_ID';
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || 'TU_TEMPLATE_ID';
const EMAILJS_PUBLIC_KEY  = import.meta.env.VITE_EMAILJS_PUBLIC_KEY  || 'TU_PUBLIC_KEY';
const CALLMEBOT_APIKEY    = import.meta.env.VITE_CALLMEBOT_APIKEY    || 'TU_CALLMEBOT_KEY';

const PSICOLOGO_EMAIL    = 'alfomipaz@gmail.com';
const PSICOLOGO_WHATSAPP = '573003348906';

export async function enviarNotificaciones(datos) {
  const resumen = buildResumen(datos);
  const results = await Promise.allSettled([
    enviarEmail(datos, resumen),
    enviarWhatsApp(datos, resumen),
  ]);
  return results;
}

function buildResumen(d) {
  return `
NUEVO FORMULARIO DE PRE-CONSULTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 Paciente: ${d.nombre_nino || '—'}
👤 Edad: ${d.edad || '—'} | Grado: ${d.grado || '—'}
🏠 Acudiente: ${d.nombre_acudiente || '—'} (${d.parentesco || '—'})
📞 Tel: ${d.telefono || '—'}

⭐ MOTIVO DE CONSULTA:
${d.motivo_principal || '—'}

Desde: ${d.desde_cuando || '—'}
Evolución: ${d.evolucion || '—'}
${d.intentos ? `Han intentado: ${d.intentos}` : ''}

📚 Colegio: ${d.colegio || '—'}
🩺 Medicación: ${d.medicacion === 'Sí' ? (d.medicacion_cual || 'Sí (no especificada)') : 'No'}
🧠 Proceso psicológico previo: ${d.ant_psicologico === 'Sí' ? 'Sí' : 'No'}

🎯 Expectativas:
${d.expectativas || '—'}
`.trim();
}

async function enviarEmail(datos, resumen) {
  // Carga EmailJS dinámicamente
  const emailjs = await import('@emailjs/browser');
  await emailjs.send(
    EMAILJS_SERVICE_ID,
    EMAILJS_TEMPLATE_ID,
    {
      to_email:      PSICOLOGO_EMAIL,
      to_name:       'Alfonso',
      paciente:      datos.nombre_nino || 'Sin nombre',
      motivo:        datos.motivo_principal || '—',
      desde_cuando:  datos.desde_cuando || '—',
      acudiente:     datos.nombre_acudiente || '—',
      telefono:      datos.telefono || '—',
      resumen_completo: resumen,
      fecha:         new Date().toLocaleString('es-CO'),
    },
    EMAILJS_PUBLIC_KEY
  );
}

async function enviarWhatsApp(datos, resumen) {
  // CallMeBot API — WhatsApp gratuito
  const texto = encodeURIComponent(
    `🔔 *Nueva pre-consulta recibida*\n\n` +
    `*Paciente:* ${datos.nombre_nino || '—'}\n` +
    `*Edad:* ${datos.edad || '—'}\n` +
    `*Tel acudiente:* ${datos.telefono || '—'}\n\n` +
    `*Motivo:* ${(datos.motivo_principal || '').slice(0, 200)}${(datos.motivo_principal || '').length > 200 ? '...' : ''}\n\n` +
    `_Abre el panel para ver el formulario completo._`
  );
  const url = `https://api.callmebot.com/whatsapp.php?phone=${PSICOLOGO_WHATSAPP}&text=${texto}&apikey=${CALLMEBOT_APIKEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('CallMeBot error');
}
