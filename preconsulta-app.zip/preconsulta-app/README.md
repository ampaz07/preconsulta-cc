# Pre-consulta · Centro Cognitivo
**Psic. Alfonso Miranda · T.P. 162714**

App web para recibir formularios de pre-consulta de padres/acudientes, con notificaciones automáticas por correo y WhatsApp.

---

## 📱 Publicar desde la tablet (sin computador)

### PASO 1 — Activar WhatsApp (CallMeBot) — 2 minutos

1. Abre WhatsApp y agrega el contacto: **+34 644 60 49 79**
2. Envíale este mensaje exacto:
   ```
   I allow callmebot to send me messages
   ```
3. Te responderá con tu **API key** (un número). Guárdalo.

---

### PASO 2 — Configurar el correo (EmailJS) — 5 minutos

1. Ve a **emailjs.com** → crea cuenta gratuita con `alfomipaz@gmail.com`
2. En el dashboard → **Add New Service** → elige Gmail → conecta tu cuenta
3. Copia el **Service ID** (ej: `service_abc123`)
4. Ve a **Email Templates** → **Create New Template**
5. En el template escribe esto:

   **Subject:** 🔔 Nueva pre-consulta: {{paciente}}

   **Body:**
   ```
   Nueva pre-consulta recibida el {{fecha}}

   PACIENTE: {{paciente}}
   ACUDIENTE: {{acudiente}}
   TELÉFONO: {{telefono}}

   MOTIVO DE CONSULTA:
   {{motivo}}

   Desde: {{desde_cuando}}

   RESUMEN COMPLETO:
   {{resumen_completo}}
   ```
6. Guarda el template y copia el **Template ID** (ej: `template_xyz456`)
7. Ve a **Account** → copia tu **Public Key** (ej: `user_AbCdEf123`)

---

### PASO 3 — Subir el código a GitHub — 5 minutos

1. Ve a **github.com** → crea cuenta si no tienes
2. Clic en **+** → **New repository**
   - Nombre: `preconsulta-cc`
   - Público ✓
   - Clic **Create repository**
3. En la página del repo vacío, clic en **uploading an existing file**
4. Sube **todos los archivos** de esta carpeta (arrastra o selecciona)
5. Clic **Commit changes**

---

### PASO 4 — Publicar en Vercel — 3 minutos

1. Ve a **vercel.com** → **Sign up with GitHub**
2. Clic **Add New Project** → selecciona `preconsulta-cc`
3. En **Environment Variables** agrega estas 4 variables:

   | Nombre | Valor |
   |--------|-------|
   | `VITE_EMAILJS_SERVICE_ID` | tu Service ID de EmailJS |
   | `VITE_EMAILJS_TEMPLATE_ID` | tu Template ID de EmailJS |
   | `VITE_EMAILJS_PUBLIC_KEY` | tu Public Key de EmailJS |
   | `VITE_CALLMEBOT_APIKEY` | tu API key de CallMeBot |

4. Clic **Deploy**
5. En ~1 minuto tendrás tu link: `preconsulta-cc.vercel.app`

---

## 🔗 Links resultantes

- **Para padres:** `https://preconsulta-cc.vercel.app` → botón "Llenar formulario"
- **Tu panel:** mismo link → botón "Ver respuestas"

---

## 📲 Cómo compartir con los padres

**Por WhatsApp:**
> Hola, antes de nuestra primera sesión le pido que diligencie este formulario breve: https://preconsulta-cc.vercel.app — toma 5 minutos y me ayuda a preparar mejor el encuentro.

**QR para sala de espera:**
Genera el QR gratis en qr-code-generator.com con tu link.

---

## ✅ Límites del plan gratuito

| Servicio | Límite gratis |
|----------|--------------|
| Vercel | Ilimitado para uso personal |
| EmailJS | 200 emails/mes |
| CallMeBot | Ilimitado |

---

## 🆘 Soporte

Si algo no funciona, escríbele a Claude con la pantalla de error y lo resolvemos.
